#include <iostream>
using namespace std;

class Number {
protected :
	int num;

public :
	Number(int n) {
		num = n;
	}

	virtual void print_it() = 0;

};

class Hex : public Number {
private :
	int sum = 0;

public :
	Hex(int n) : Number(n) {}

	void print_it() {
		cout << std::hex << "0x" << num << endl;
	}
};

class Octal : public Number {
private :
	int sum = 0;
public:
	Octal(int n) : Number(n) {}

	void print_it() {
		cout << std::oct << num << endl;
	}
};

class Decimal : public Number {
public:
	Decimal(int n) : Number(n) {}

	void print_it() {
		cout << std::dec << num << endl;
	}
};



int main() {
	Number *num;
	Hex hex(123);
	Octal oct(123);
	Decimal dec(123);

	dec.print_it();
	oct.print_it();
	hex.print_it();


	system("pause");
	return 0;
}