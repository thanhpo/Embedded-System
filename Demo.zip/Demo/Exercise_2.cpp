#include <iostream>
using namespace std;

class Pet {
public :

	virtual void home() = 0;
};

class Dog : public Pet {
public:

	void home() {
		cout << "Dog live in land" << endl;
	}

};

class Fish : public Pet {
public:

	void home() {
		cout << "Fish live in water" << endl;
	}

};


int main() {
	Pet *pet;
	Dog dog;
	Fish fish;

	pet = &dog;
	pet->home();

	pet = &fish;
	pet->home();


	system("pause");
	return 0;
}