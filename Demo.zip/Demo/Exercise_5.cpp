#include <iostream>
#include <string>

using namespace std;

template <class T>
class Node {
public:
	T info;
	Node<T> *next;

	Node(T const &data) {
		info = data;
	}
};

template <class T>
class StackOrQueue {
protected:
	Node<T> *head = NULL;
	Node<T> *last = NULL;

public:

	Node<T>* pop() {
		Node<T> *remove = NULL;

		if (isEmpty()) {
			cout << "Linked List Empty" << endl;
			return NULL;
		}
		else {
			remove = head;
			head = head->next;
			remove->next = NULL;
			
			cout << "Pop Value = " << remove->info << endl;
			return remove;
		}
	}

	bool isEmpty() {
		return head == NULL;
	}


	void printAll() {
		Node<T> *ptr = head;

		while (ptr != NULL) {
			cout << ptr->info << " ";
			ptr = ptr->next;
		}

		cout << endl;
	}
};

template <class T>
class Stack : public StackOrQueue<T> {
public :

	void push(T const &elem) {
		Node<T> *link = new Node<T>(elem);

		if (StackOrQueue::isEmpty()) {
			StackOrQueue::last = link;
		}

		link->next = StackOrQueue::head;
		StackOrQueue::head = link;

	}


};

template <class T>
class Queue : public StackOrQueue<T> {
public:

	void insert(T const &elem) {
		Node<T> *link = new Node<T>(elem);
		link->next = NULL;

		if (StackOrQueue::isEmpty()) {
			StackOrQueue::head = link;
		}
		else {
			StackOrQueue::last->next = link;
		}

		StackOrQueue::last = link;
	}
};

class demo
{
private:
	int num;

public:
	int getNum() {
		return num;
	}
};


int main() {

	Stack<int> num;
	Stack<string> str;

	Queue<int> so;
	Queue<string> chuoi;

	Node<int> *popNum = NULL;
	Node<string> *popString = NULL;

	// Stack 
	num.push(100);
	num.push(200);
	num.push(300);
	num.push(400);
	num.push(500);
	num.push(600);

	num.printAll();

	popNum = num.pop();
	popNum = num.pop();
	popNum = num.pop();
	popNum = num.pop();
	popNum = num.pop();
	popNum = num.pop();
	popNum = num.pop();

	str.push("xin");
	str.push("chao");
	str.push("Viet");
	str.push("Nam");

	str.printAll();

	popString = str.pop();
	popString = str.pop();
	popString = str.pop();
	popString = str.pop();
	popString = str.pop();

	// Queue
	so.insert(10);
	so.insert(20);
	so.insert(30);
	so.insert(40);

	so.printAll();

	popNum = so.pop();
	popNum = so.pop();
	popNum = so.pop();
	popNum = so.pop();
	popNum = so.pop();

	chuoi.insert("xin");
	chuoi.insert("chao");
	chuoi.insert("Viet");
	chuoi.insert("Nam");

	chuoi.printAll();

	popString = chuoi.pop();
	popString = chuoi.pop();
	popString = chuoi.pop();
	popString = chuoi.pop();
	popString = chuoi.pop();


	system("pause");
	return 0;
}