#include <iostream>
using namespace std;

class SingleTon {
private:
	static SingleTon *instance;
	SingleTon() {}

public:

	static SingleTon* getInstance() {
		if (instance == NULL)
			instance = new SingleTon();

		return instance;
	}

	void doSomething() {
		cout << "I'm SingleTon" << endl;
	}
};

//SingleTon* SingleTon::instance = NULL;

int main() {
	SingleTon::getInstance()->doSomething();


	system("pause");
	return 0;
}