#include <iostream>
using namespace std;

struct Node {
	int data;
	Node *next;
};

Node *head = NULL;
Node *last = NULL;

bool isEmpty() {
	return head == NULL;
}

void insertFist(int d) {
	Node *link = new Node;
	link->data = d;

	link->next = head;
	head = link;
}

void insertLast(int d) {
	Node *link = new Node;
	link->data = d;

	if (isEmpty()) {
		head = link;
	}
	else {
		last->next = link;
	}

	link->next = NULL;
	last = link;
}

Node* deletion(int key) {

	Node* current = head;
	Node* previous = NULL;

	if (head == NULL) {
		return NULL;
	}

	while (current->data != key) {

		if (current->next == NULL) {
			return NULL;
		}
		else {
			previous = current;
			current = current->next;
		}
	}

	if (current == head) {
		head = head->next;
	}
	else {
		previous->next = current->next;
	}

	return current;
}

void printAll() {
	Node *ptr = head;

	while (ptr != NULL) {
		cout << ptr->data << " ";
		ptr = ptr->next;
	}

	cout << endl;
}

int main() {
	insertLast(100);
	insertLast(200);
	insertLast(300);
	insertLast(400);

	printAll();

	deletion(100);
	
	printAll();


	system("pause");
	return 0;
}