#include <iostream>
using namespace std;

class Shape {
protected:
	int width, height;

public:
	Shape(int a = 0, int b = 0) {
		width = a;
		height = b;
	}

	virtual int area() = 0;
};

class Square : public Shape {
private:
	int edge;
public:
	Square(int e) {
		edge = e;
	}

	int area() {
		return (edge * 4);
	}
};

class Circle : public Shape {
private:
	int radius;
public:
	Circle(int r) {
		radius = r;
	}

	int area() {
		return (2 * 3.14 * radius);
	}
};

class EquilateralTriangle : public Shape {
public:
	EquilateralTriangle(int a = 0, int b = 0) : Shape(a, b) {}

	int area() {
		return (width * height) / 2;
	}
};

int main() {
	Shape *shape;
	Square square(4);
	Circle circle(4);
	EquilateralTriangle eTri(4, 5); 

	shape = &square;
	cout << shape->area() << endl;

	shape = &circle;
	cout << shape->area() << endl;

	shape = &eTri;
	cout << shape->area() << endl;

	system("pause");
	return 0;
}