#include <iostream>
using namespace std;

struct Node {
	int data;
	Node *prev;
	Node *next;
};

class LinkedList {
private:
	Node *head = NULL;
	Node *last = NULL;

	bool isEmpty() {
		return head == NULL;
	}

public:
	
	// Adds aan element at the beginning of the list
	void addFirst(int data) {
		Node *link = new Node;
		link->data = data;
		link->prev = NULL;
		
		if (isEmpty()) {
			last = link;
		}
		else {
			head->prev = link;
		}

		link->next = head;

		head = link;
	}

	// Adds an element at the end of the list
	void addLast(int data) {
		Node *link = new Node;
		link->data = data;
		link->next = NULL;

		if (isEmpty()) {
			head = link;	
		}
		else {
			last->next = link;
		}

		link->prev = last;
		last = link;
	}

	// Delete an Item
	void del(int data) {
		Node *ptr = head;
		Node *previous = NULL;

		if(head == NULL) {
			cout << "Linked List is empty!" << endl;
			return;
		}

		while (ptr->data != data) {
			if (ptr->next == NULL) {
				cout << "Not found" << endl;
				return;
			}
			else {
				ptr = ptr->next;
			}
		}

		previous = ptr->prev;

		if(ptr == head) {
			head = ptr->next;
		}
		else {
			previous->next = ptr->next;
		}

		if (ptr == last) {
			last = ptr->prev;
		}
		else {
			ptr->next->prev = previous;
		}

		cout << "Delete successful" << endl;
	}

	// Show number of Items
	int length() {
		int length = 0;
		Node *ptr = head;

		while (ptr != NULL) {
			length++;
			ptr = ptr->next;
		}

		return length;
	}

	// Find min Item
	Node* findMin() {
		if (isEmpty()) {
			return NULL;
		}

		Node *ptr = head;
		Node *minItem = head;

		int minValue = head->data;
		while (ptr != NULL) {
			if (ptr->data < minValue) {
				minValue = ptr->data;
				minItem = ptr;
			}
			
			ptr = ptr->next;
		}

		return minItem;
	}

	//Find max Item
	Node* findMax() {
		if (isEmpty()) {
			return NULL;
		}

		Node *ptr = head;
		Node *maxItem = head;

		int maxValue = head->data;
		while (ptr != NULL) {
			if (ptr->data > maxValue) {
				maxValue = ptr->data;
				maxItem = ptr;
			}

			ptr = ptr->next;
		}

		return maxItem;
	}

	//Find Item
	Node* find(int data) {
		Node *ptr = head;

		while (ptr != NULL) {
			if (ptr->data == data) {
				return ptr;
			}

			ptr = ptr->next;
		}

		return NULL;
	}

	//Print all Items
	void printAll() {
		Node *ptr = head;

		while (ptr != NULL) {
			cout << ptr->data << " ";
			ptr = ptr->next;
		}

		cout << endl;
	}

	
};

int main() {
	LinkedList list;
	LinkedList ds;

	Node *minItem = NULL;
	Node *maxItem = NULL;
	Node *item;

	int numChoice;
	int data;

	do {
		cout << "==================================" << endl;
		cout << "Doubly Linked List Operations Menu" << endl;
		cout << "==================================" << endl;
		cout << "\n1. Add a new Item";
		cout << "\n2. Delete an Item";
		cout << "\n3. Show number of Items";
		cout << "\n4. Find min Item";
		cout << "\n5. Find max Item";
		cout << "\n6. Find Item";
		cout << "\n7. Print all Items";
		cout << "\n8. Exit";
		cout << "\nEnter your choice : ";

		cin >> numChoice;
	
		system("cls");

		switch (numChoice) {
		case 1:
			cout << "Value add = ";
			cin >> data;
			list.addLast(data);
			break;
		case 2:
			cout << "Value delete = ";
			cin >> data;
			list.del(data);
			break;
		case 3:
			cout << "Number of Items : " << list.length() << endl;
			break;
		case 4:
			minItem = list.findMin();
			if (minItem != NULL) {
				cout << "Min Item : " << minItem->data << endl;
			}
			else {
				cout << "Not Found" << endl;
			}
			break;
		case 5:
			maxItem = list.findMax();
			if (maxItem != NULL) {
				cout << "Max Item : " << maxItem->data << endl;
			}
			else {
				cout << "Not Found" << endl;
			}
			break;
		case 6:
			cout << "Value need find = ";
			cin >> data;
			item = list.find(data);
			if (item != NULL) {
				cout << "Item found : " << item->data << endl;
			}
			else {
				cout << "Not Found" << endl;
			}
			break;
		case 7:
			cout << "Print all items : " << endl;
			list.printAll();
			break;
		case 8 :
			return 0;
		default:
			cout << "Please choose a selection " << endl;
		}

		system("pause");
	} while (numChoice != 8);
	
	return 0;
}