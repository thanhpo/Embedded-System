#include <iostream>
using namespace std;

class Box {
	public:

		void anOperation() {
			get();
		}

		virtual void get() = 0;
};

class Box1 : public Box {
private:
	static int cnt;
public :
	void get() {
		cout << "I'm Box 1 " << endl;
	}

	static int getCnt() {
		cout << "hello";
		return 123;
	}
};

int Box1::cnt = 0;



class Box2 : public Box {
public:
	void get() {
		cout << "I'm Box 2 " << endl;
	}
};


int main() {
	Box *box = new Box2();

	box->anOperation();

	system("pause");
	return 0;
}