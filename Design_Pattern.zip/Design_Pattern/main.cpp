#include <iostream>
#include <string>
using namespace std;


/*
	Shape
*/
class Shape 
{
private:
	int position[2];

public:
	Shape *next;

public:
	virtual void draw() = 0;

};

// Circle 2D
class Circle_2D :
	public Shape
{
private:
	int radius;

public:
	void draw() {
		cout << "Circle 2D ";
	}

	void setRadius(int rad) {
		radius = rad;
	}
};

// Circle 3D
class Circle_3D :
	public Shape
{
private:
	int radius;

public:
	void draw() {
		cout << "Circle 3D ";
	}
};

// Rectangle 2D
class Rectangle_2D :
	public Shape 
{
private:
	int width, height;

public:
	void draw() {
		cout << "Rectangle 2D ";
	}
};

// Rectangle 3D
class Rectangle_3D :
	public Shape
{
private:
	int width, height;

public:
	void draw() {
		cout << "Rectangle 3D ";
	}
};


/*
	Abstract Factory
*/
class AbstractFactory {
public:
	virtual Shape* getCircle() = 0;
	virtual Shape* getRectangle() = 0;

};

// Circle Factory
class _2DFactory :
	public AbstractFactory
{
public:
	Shape* getCircle() {
		return new Circle_2D;
	}

	Shape* getRectangle() {
		return new Circle_3D;
	}
};

// Rectangle Factory
class _3DFactory :
	public AbstractFactory
{
public:
	Shape* getCircle() {
		return new Rectangle_2D;
	}

	Shape* getRectangle() {
		return new Rectangle_3D;
	}
};

/*
	Factory Producer
*/
class FactoryProducer 
{
public:
	static AbstractFactory* getFactory(string choice) {
		if (choice == "Circle") {
			return new CircleFactory;
		}
		else if (choice == "Rectangle") {
			return new RectangleFactory;
		}

		return NULL;
	}
};

/*
	Linked List
*/
class LinkedList {
private:
	Shape *head = NULL;
	Shape *last = NULL;

	bool isEmpty() {
		return head == NULL;
	}

public:

	// Adds an element at the beginning of the list
	void addFirst(string factoryChoice, string style, int[] position, int radius, int width, int height) {
		AbstractFactory *factory = FactoryProducer::getFactory(factoryChoice);
		if (style == "2D") {
			Shape *link = factory->get2D();
			link->setRa = data;
		}
		else if (style == "3D") {
			Shape *link = factory->get3D();
		}
		
		
		
		if (isEmpty()) {
			head = link;
		}
		else {
			last->next = link;
		}

		link->next = NULL;
		last = link;
	}

	Shape* deletion(int key) {

		Shape* current = head;
		Shape* previous = NULL;

		if (head == NULL) {
			return NULL;
		}

		while (current->data != key) {

			if (current->next == NULL) {
				return NULL;
			}
			else {
				previous = current;
				current = current->next;
			}
		}

		if (current == head) {
			head = head->next;
		}
		else {
			previous->next = current->next;
		}

		return current;
	}

	// Show number of Items
	int length() {
		int length = 0;
		Shape *ptr = head;

		while (ptr != NULL) {
			length++;
			ptr = ptr->next;
		}

		return length;
	}

	//Find Item
	Node* find(int data) {
		Node *ptr = head;

		while (ptr != NULL) {
			if (ptr->data == data) {
				return ptr;
			}

			ptr = ptr->next;
		}

		return NULL;
	}

	//Print all Items
	void printAll() {
		Node *ptr = head;

		while (ptr != NULL) {
			cout << ptr->data << " ";
			ptr = ptr->next;
		}

		cout << endl;
	}


};

int main() {
	AbstractFactory *factory = FactoryProducer::getFactory("Circle");
	Shape *shape = factory->get2D();

	shape->draw();


	system("pause");
	return 0;
}